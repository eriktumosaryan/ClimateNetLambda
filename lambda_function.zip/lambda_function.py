import mysql.connector
from mysql.connector import Error

config = {
        'host' : 'database-3.c8nb4zcoufs1.us-east-1.rds.amazonaws.com',
        'database' : 'ClimateNet',
        'user' : 'admin',
        'password' : 'lovetumolabs',
}

def connect_to_db(config):
    try:
        connection = mysql.connector.connect(**config)
        cursor = connection.cursor()
        status = connection.is_connected()
    except Error as err:
        status = err
    return connection, cursor, status

def lambda_handler(event, context):
    connection, cursor, status = connect_to_db(config)
    return status

# if __name__ == '__main__':
#     print("i have start ")
#     lambda_handler(1, 1)
